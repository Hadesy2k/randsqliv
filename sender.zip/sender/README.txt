
                                =======[ THANKS FOR USING THIS SENDER ]=======


╔╦╗╔═╗╦═╗╔╦╗  ╔═╗╔═╗  ╔═╗╔═╗╦═╗╦  ╦╦╔═╗╔═╗
 ║ ║╣ ╠╦╝║║║  ║ ║╠╣   ╚═╗║╣ ╠╦╝╚╗╔╝║║  ║╣
 ╩ ╚═╝╩╚═╩ ╩  ╚═╝╚    ╚═╝╚═╝╩╚═ ╚╝ ╩╚═╝╚═╝

1. Expire on 1 Months
2. Gruantee Junk 2 Times
3. Discount 15% For 1 Friend
4. Free Update
5. Out From Member If Sell This Stuff Ilegal


[
REPORT ANY ERROR TO -->
WELL L on Skype
+6282247528886 on Whatsapp
]


[ I WILL NOT HELP ANY PEOPLE WHO DONT BUY THIS SENDER FROM ME IF THEY GET ERROR ON THIS SENDER !!! ]


[

NB-->

Extract W3LL SENDER.zip BEFORE DO STEP BELLOW

Put Your Mailist On -->

File Folder > mailist > W3LL_LIST.txt

HOW TO USE -->

1. RIGHT CLICK ON WORKSPACE ON LEFT SIDE
2. CHOOSE 'Open Terminal Here'
3. PUT COMMAND 'php W3LL.php'

]

[

--> SMTP settings <--

smtpserver --> Fill in with the smtp server you're using
smtpuser   --> Fill in with the smtp user you're using
smtppass   --> Fill in the smtp password you use
smtpport   --> Fill in with the smtp port you're using
priority   --> Fill 1 for high priority, fill 0 for normal priority

--> End <--

--> Mail settings <--

mailist  --> Fill in the name of your mailist file.
fromname --> Fill the fromname to your liking. If you use the userandom feature, you do not need to fill in this section.
frommail --> Fill frommail to your liking. If you use the userandom feature, you do not need to fill in this section.
subject  --> Fill frommail to your liking. If you use the userandom feature, you do not need to fill in this section.
msgfile  --> Fill in your letter file name.

--> End <--


--> Other <--

userremoveline --> Fill 1 to use. 0 for not. If this feature is enabled, email-list already sent messages will be removed from your mailist.
replacement    --> Fill 1 to use. 0 for not. This works to me replace your letter with a predefined format.
userandom      --> Fill 1 to use. 0 for not. This works to enable random features fromname, frommail, and subject.
sleeptime      --> Duration of sending pauses per email in seconds.
randurl        --> This is a random url feature. Serves to randomize the url with the url you have specified. How to fill it is as follows-->   randurl = array ("http-->//yoururl1.com", "http-->//yoururl2.com", "etc");

--> End <--

--> Subject format <--

$date		--> Show Date & Time Format ( NOT RANDOM )
$randip		-->	Random IP Location
$country	-->	Random Country
$browser	-->	Random Browser
$os			--> Random Os

--> End <--

--> Letter format <--

++w3ll_email++	 		-->  Show The Recipient's Email ( NOT RANDOM )
++w3ll_secret_email++ 	-->  Show The Recipient's Email With Secret Mode ( NOT RANDOM )
++w3ll_user++			-->  Show The Recipient's User Email ( NOT RANDOM )
++w3ll_domain++			-->  Show The Recipient's Email Domain ( NOT RANDOM )
++w3ll_date++			-->  Show Date Format ( NOT RANDOM )
++w3ll_time++			-->  Show Time Format ( Not Random )
++w3ll_short++			-->  Show Scam Link ( NOT RANDOM )
++w3ll_subject++		-->  Random subject
++w3ll_frommail++		-->  Random From mail
++w3ll_fromname++		-->  Random From Name
++w3ll_randomip++		-->  Random IP Location
++w3ll_country++		-->  Random Country
++w3ll_browser++		-->  Random Browser
++w3ll_os++				-->  Random Os
++w3ll_randstring++		-->	 Random String
++w3ll_number1++		-->  Random 1 Number
++w3ll_number2++		-->  Random 2 Number
++w3ll_number3++		-->  Random 3 Number
++w3ll_number4++		-->  Random 4 Number
++w3ll_number5++		-->  Random 5 Number
++w3ll_number6++		-->  Random 6 Number
++w3ll_number7++		-->  Random 7 Number
++w3ll_number8++		-->  Random 8 Number
++w3ll_number9++		-->  Random 9 Number
++w3ll_number10++		-->  Random 10 Number

--> End <--

]

╔╦╗╔═╗╦═╗╔╦╗  ╔═╗╔═╗  ╔═╗╔═╗╦═╗╦  ╦╦╔═╗╔═╗
 ║ ║╣ ╠╦╝║║║  ║ ║╠╣   ╚═╗║╣ ╠╦╝╚╗╔╝║║  ║╣
 ╩ ╚═╝╩╚═╩ ╩  ╚═╝╚    ╚═╝╚═╝╩╚═ ╚╝ ╩╚═╝╚═╝

1. Expire on 1 Months
2. Gruantee Junk 2 Times
3. Discount 15% For 1 Friend
4. Free Update
5. Out From Member If Sell This Stuff Ilegal


                                =======[ THANKS FOR USING THIS SENDER ]=======