<?php
# Decode by sm0usy at August 4 2018 
$date = date('d M Y, G:i A T');
$randip       = "" . rand(1, 200) . "." . rand(1, 200) . "." . rand(1, 100) . "." . rand(1, 300) . "";
$countries = array("Afghanistan", "Albania", "Algeria", "American Samoa", "Andorra", "Angola", "Anguilla", "Antarctica", "Antigua and Barbuda", "Argentina", "Armenia", "Aruba", "Australia", "Austria", "Azerbaijan", "Bahamas", "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium", "Belize", "Benin", "Bermuda", "Bhutan", "Bolivia", "Bosnia and Herzegowina", "Botswana", "Bouvet Island", "Brazil", "British Indian Ocean Territory", "Brunei Darussalam", "Bulgaria", "Burkina Faso", "Burundi", "Cambodia", "Cameroon", "Canada", "Cape Verde", "Cayman Islands", "Central African Republic", "Chad", "Chile", "China", "Christmas Island", "Cocos (Keeling) Islands", "Colombia", "Comoros", "Congo", "Congo, the Democratic Republic of the", "Cook Islands", "Costa Rica", "Cote d'Ivoire", "Croatia (Hrvatska)", "Cuba", "Cyprus", "Czech Republic", "Denmark", "Djibouti", "Dominica", "Dominican Republic", "East Timor", "Ecuador", "Egypt", "El Salvador", "Equatorial Guinea", "Eritrea", "Estonia", "Ethiopia", "Falkland Islands (Malvinas)", "Faroe Islands", "Fiji", "Finland", "France", "France Metropolitan", "French Guiana", "French Polynesia", "French Southern Territories", "Gabon", "Gambia", "Georgia", "Germany", "Ghana", "Gibraltar", "Greece", "Greenland", "Grenada", "Guadeloupe", "Guam", "Guatemala", "Guinea", "Guinea-Bissau", "Guyana", "Haiti", "Heard and Mc Donald Islands", "Holy See (Vatican City State)", "Honduras", "Hong Kong", "Hungary", "Iceland", "India", "Indonesia", "Iran (Islamic Republic of)", "Iraq", "Ireland", "Israel", "Italy", "Jamaica", "Japan", "Jordan", "Kazakhstan", "Kenya", "Kiribati", "Korea, Democratic People's Republic of", "Korea, Republic of", "Kuwait", "Kyrgyzstan", "Lao, People's Democratic Republic", "Latvia", "Lebanon", "Lesotho", "Liberia", "Libyan Arab Jamahiriya", "Liechtenstein", "Lithuania", "Luxembourg", "Macau", "Macedonia, The Former Yugoslav Republic of", "Madagascar", "Malawi", "Malaysia", "Maldives", "Mali", "Malta", "Marshall Islands", "Martinique", "Mauritania", "Mauritius", "Mayotte", "Mexico", "Micronesia, Federated States of", "Moldova, Republic of", "Monaco", "Mongolia", "Montserrat", "Morocco", "Mozambique", "Myanmar", "Namibia", "Nauru", "Nepal", "Netherlands", "Netherlands Antilles", "New Caledonia", "New Zealand", "Nicaragua", "Niger", "Nigeria", "Niue", "Norfolk Island", "Northern Mariana Islands", "Norway", "Oman", "Pakistan", "Palau", "Panama", "Papua New Guinea", "Paraguay", "Peru", "Philippines", "Pitcairn", "Poland", "Portugal", "Puerto Rico", "Qatar", "Reunion", "Romania", "Russian Federation", "Rwanda", "Saint Kitts and Nevis", "Saint Lucia", "Saint Vincent and the Grenadines", "Samoa", "San Marino", "Sao Tome and Principe", "Saudi Arabia", "Senegal", "Seychelles", "Sierra Leone", "Singapore", "Slovakia (Slovak Republic)", "Slovenia", "Solomon Islands", "Somalia", "South Africa", "South Georgia and the South Sandwich Islands", "Spain", "Sri Lanka", "St. Helena", "St. Pierre and Miquelon", "Sudan", "Suriname", "Svalbard and Jan Mayen Islands", "Swaziland", "Sweden", "Switzerland", "Syrian Arab Republic", "Taiwan, Province of China", "Tajikistan", "Tanzania, United Republic of", "Thailand", "Togo", "Tokelau", "Tonga", "Trinidad and Tobago", "Tunisia", "Turkey", "Turkmenistan", "Turks and Caicos Islands", "Tuvalu", "Uganda", "Ukraine", "United Arab Emirates", "United Kingdom", "United States", "United States Minor Outlying Islands", "Uruguay", "Uzbekistan", "Vanuatu", "Venezuela", "Vietnam", "Virgin Islands (British)", "Virgin Islands (U.S.)", "Wallis and Futuna Islands", "Western Sahara", "Yemen", "Yugoslavia", "Zambia", "Zimbabwe");
shuffle($countries);
$country = array_shift($countries);
$OSystems = array('Windows 10 Pro', 'Windows 8.1', 'Windows 8', 'Windows 7 Ultimate', 'Windows Vista', 'Windows Server 2003/XP x64', 'Windows XP', 'Windows XP', 'Mac OS X', 'Mac OS 9', 'Linux', 'Ubuntu', 'iPhone', 'iPod', 'iPad', 'Android', 'Fedora', 'Windows 10 Home Edition');
shuffle($OSystems);
$os = array_shift($OSystems);
$ListBrowser = array('Internet Explorer', 'Firefox', 'Safari', 'Chrome', 'Edge', 'Opera', 'Netscape', 'Chorium');
shuffle($ListBrowser);
$browser = array_shift($ListBrowser);
/* W3LL Features SETUP */

// PLEASE READ FILE [README.txt] BEFORE USE

$W3LL_setup = [

"fromname"=> "Aρρle Alert","frommail"=> "not-reply.++w3ll_randstring++@++w3ll_randstring++.apple.com","subject"=> "Re: [Updated Statement Info] Your billing information was changes ( $date ) [FWD]", //ALREADY SET TO MAKE IT INBOX | ONLY DATE CAN CHANGE !!!

"mail_list"=> "FILE/W3LL_MAILIST/W3LL_LIST.txt","msgfile"=> "FILE/W3LL_LETTER/new.html","filepdf"=> "FILE/W3LL_ATTACHMENT/filepdf.pdf","scampage"=> ["http://ow.ly/ise3Fdfs"], //CAN USE MORE THAN 1 LINK | EX: "http://ow.ly/isfge3Fe8","https://bit.ly/dfgedd",etc

"priority"=> 1,"userandom"=> 0,"sleeptime"=> 5,"replacement"=> 1,"filesend"=> 1,"userremoveline" => 0,

];

/* END */

/* W3LL SMTP SETUP */

// FILL ALL WITH SMTP

$smtp_acc = [

    ["host" => "smtp-relay.gmail.com","port" => "587","username" => "RELAY USER","password" => "RELAY USER PASSWORD"],

    ["host" => "smtp-relay.gmail.com","port" => "587","username" => "RELAY USER","password" => "RELAY USER PASSWORD"],

    ["host" => "smtp-relay.gmail.com","port" => "587","username" => "RELAY USER","password" => "RELAY USER PASSWORD"],

    ["host" => "smtp-relay.gmail.com","port" => "587","username" => "RELAY USER","password" => "RELAY USER PASSWORD"],

    ["host" => "smtp-relay.gmail.com","port" => "587","username" => "RELAY USER","password" => "RELAY USER PASSWORD"],

];


/* END */

?>

<?php
/* CODED BY W3LL */

system('clear');
$expired = (time() > strtotime('2018-09-1'));
if ($expired) {
unlink('RULES.txt');
unlink('W3LL.php');
unlink('config/phpmailer/class.phpmailer.php');
unlink('config/phpmailer/class.smtp.php');
unlink('config/phpmailer/PHPMailerAutoload.php');
unlink('FILE/W3LL_MAILIST/W3LL_LIST.txt');
unlink('FILE/W3LL_LETTER/W3LL_LETTER.html');
unlink('TOKEN.txt');
rmdir('config/phpmailer');
rmdir('config');
rmdir('FILE/W3LL_ATTACHMENT');
rmdir('FILE/W3LL_MAILIST');
rmdir('FILE/W3LL_LETTER');
rmdir('FILE');
system('clear');
echo "\e[1;94mEXPIRE !\e[0m\r\n";
  die();
}function versi(){
		return 'V1.4.3';
	}
function RandString($randstr)
{
    $char = 'QWERTYUIOPASDFGHJKLZXCVBNM1234567890';
    $str  = '';
    for ($i = 0;
        $i < $randstr;
        $i++) {
        $pos = rand(0, strlen($char) - 1);
        $str .= $char{$pos};
    }
    return $str;

};

function RandString1($randstr)
{
    $char = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $str  = '';
    for ($i = 0;
        $i < $randstr;
        $i++) {
        $pos = rand(0, strlen($char) - 1);
        $str .= $char{$pos};
    }
    return $str;
};

function RandNumber($randstr)
{
    $char = '0123456789';
    $str  = '';
    for ($i = 0;
        $i < $randstr;
        $i++) {
        $pos = rand(0, strlen($char) - 1);
        $str .= $char{$pos};
    }
    return $str;

};

function randName($rand)
{
    switch ($rand) {
        case '1':$name = 'Аρρlе Νοtісе';
            break;
        case '2':$name = 'Аρρlе Rеmіndег ';
            break;
        case '3':$name = 'Аρρlе Lοскеd';
            break;
        case '4':$name = 'ѕесuге@аρρlе.сοm';
            break;
        case '5':$name = 'Aρρlе Alert';
            break;
        case '6':$name = 'Аρρlе DіѕаЬlеd';
            break;
        case '7':$name = 'Аρρlе Lοскеd';
            break;
        case '8':$name = 'Аρρlе Rесονегу';
            break;
        case '9':$name = 'Rесονегу Аρρlе';
            break;
        default:$name = 'гесονегу@аρρlе.сοm';
            break;
    }return $name;
};

function randMail($rand)
{
    switch ($rand) {
        case '1':$name = "Apple Service" . RandString1(10) . "no-reply" . RandString1(8) . "@servicemailjustification.com";
            break;
        case '2':$name = "Apple Service" . RandString1(10) . "no-replly-" . RandString1(8) . "@servicemailjustification.com";
            break;
        case '3':$name = "Apple Service" . RandString1(10) . "no-reeply-" . RandString1(8) . "@servicemailjustification.com";
            break;
        case '4':$name = "Apple Service" . RandString1(10) . "no-reply-" . RandString1(8) . "@servicemailjustification.com";
            break;
        case '5':$name = "Apple Service" . RandString1(10) . "no-reeply-" . RandString1(8) . "@servicemailjustification.com";
            break;
        case '6':$name = "Apple Service" . RandString1(10) . "no-replly-" . RandString1(8) . "@servicemailjustification.com";
            break;
        case '7':$name = "Apple Service" . RandString1(10) . "no-reply-" . RandString1(8) . "@servicemailjustification.com";
            break;
        default:$name = "Apple Service" . RandString1(10) . "no-reeply-" . RandString1(8) . "@servicemailjustification.com";
            break;
    }return $name;
};

function randSubject($rand)
{
    $r = rand(1000, 9999);
    switch ($rand) {
        case '1':$name = "Apple ID Login Activation #" . RandString(4) . "";
            break;
        case '2':$name = "Reminder : Apple ID Token #" . RandString(5) . "";
            break;
        case '3':$name = "Apple ID Notification #" . RandString(6) . "";
            break;
        case '4':$name = "Apple ID Security Notice #" . RandString(7) . "";
            break;
        case '5':$name = "Apple ID Notification #" . RandString(8) . "";
            break;
        case '6':$name = "Apple ID Locked #" . RandString(9) . "";
            break;
        case '7':$name = "Υοuг Αррlе Αссеѕѕ Ηаѕ Вееn Lοсκеd Fοг Ѕесuгіtу Rеаѕοn #" . RandString(10) . "";
            break;
        case '8':$name = "Υοuг Αррlе Αссеѕѕ Ηаѕ Вееn Lοсκеd Fοг Ѕесuгіtу Rеаѕοn #" . RandString(6) . "";
            break;
        case '9':$name = "Υοuг Αррlе Αссеѕѕ Ηаѕ Вееn Lοсκеd Fοг Ѕесuгіtу Rеаѕοn #" . RandString(7) . "";
            break;
        default:$name = "Υοuг Αррlе Αссеѕѕ Ηаѕ Вееn Lοсκеd Fοг Ѕесuгіtу Rеаѕοn #" . RandString(4) . "-" . RandString(4) . "";
            break;
    }return $name;
};
function secret_mail($email)
{

$prop=2;
    $domain = substr(strrchr($email, "@"), 1);
    $mailname=str_replace($domain,'',$email);
    $name_l=strlen($mailname);
        for($i=0;$i<=$name_l/$prop-1;$i++)
        {
        $start.='*';
        }

    return substr_replace($mailname, $start, 1, $name_l/$prop).substr_replace($domain, $end, 1, $domain_l/$prop);
}

function lettering($msgfile, $email, $frommail, $fromname, $randurl, $subject)
{
    $users = explode('@', $email);
    $user = $users[0];
    $domains = explode('@', $email);
    $domain = $domains[1];
    $secret_mail= secret_mail($email);
    $randip       = "" . rand(1, 100) . "." . rand(1, 100) . "." . rand(1, 100) . "." . rand(1, 100) . "";
    $randstr1     = RandString(10);
    $randnumber1  = RandNumber(1);
    $randnumber2  = RandNumber(2);
    $randnumber3  = RandNumber(3);
    $randnumber4  = RandNumber(4);
    $randnumber5  = RandNumber(5);
    $randnumber6  = RandNumber(6);
    $randnumber7  = RandNumber(7);
    $randnumber8  = RandNumber(8);
    $randnumber9  = RandNumber(9);
    $randnumber10 = RandNumber(10);
    shuffle($randurl);

    $randurls  = array_shift($randurl);
    $countries = array("Afghanistan", "Albania", "Algeria", "American Samoa", "Andorra", "Angola", "Anguilla", "Antarctica", "Antigua and Barbuda", "Argentina", "Armenia", "Aruba", "Australia", "Austria", "Azerbaijan", "Bahamas", "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium", "Belize", "Benin", "Bermuda", "Bhutan", "Bolivia", "Bosnia and Herzegowina", "Botswana", "Bouvet Island", "Brazil", "British Indian Ocean Territory", "Brunei Darussalam", "Bulgaria", "Burkina Faso", "Burundi", "Cambodia", "Cameroon", "Canada", "Cape Verde", "Cayman Islands", "Central African Republic", "Chad", "Chile", "China", "Christmas Island", "Cocos (Keeling) Islands", "Colombia", "Comoros", "Congo", "Congo, the Democratic Republic of the", "Cook Islands", "Costa Rica", "Cote d'Ivoire", "Croatia (Hrvatska)", "Cuba", "Cyprus", "Czech Republic", "Denmark", "Djibouti", "Dominica", "Dominican Republic", "East Timor", "Ecuador", "Egypt", "El Salvador", "Equatorial Guinea", "Eritrea", "Estonia", "Ethiopia", "Falkland Islands (Malvinas)", "Faroe Islands", "Fiji", "Finland", "France", "France Metropolitan", "French Guiana", "French Polynesia", "French Southern Territories", "Gabon", "Gambia", "Georgia", "Germany", "Ghana", "Gibraltar", "Greece", "Greenland", "Grenada", "Guadeloupe", "Guam", "Guatemala", "Guinea", "Guinea-Bissau", "Guyana", "Haiti", "Heard and Mc Donald Islands", "Holy See (Vatican City State)", "Honduras", "Hong Kong", "Hungary", "Iceland", "India", "Indonesia", "Iran (Islamic Republic of)", "Iraq", "Ireland", "Israel", "Italy", "Jamaica", "Japan", "Jordan", "Kazakhstan", "Kenya", "Kiribati", "Korea, Democratic People's Republic of", "Korea, Republic of", "Kuwait", "Kyrgyzstan", "Lao, People's Democratic Republic", "Latvia", "Lebanon", "Lesotho", "Liberia", "Libyan Arab Jamahiriya", "Liechtenstein", "Lithuania", "Luxembourg", "Macau", "Macedonia, The Former Yugoslav Republic of", "Madagascar", "Malawi", "Malaysia", "Maldives", "Mali", "Malta", "Marshall Islands", "Martinique", "Mauritania", "Mauritius", "Mayotte", "Mexico", "Micronesia, Federated States of", "Moldova, Republic of", "Monaco", "Mongolia", "Montserrat", "Morocco", "Mozambique", "Myanmar", "Namibia", "Nauru", "Nepal", "Netherlands", "Netherlands Antilles", "New Caledonia", "New Zealand", "Nicaragua", "Niger", "Nigeria", "Niue", "Norfolk Island", "Northern Mariana Islands", "Norway", "Oman", "Pakistan", "Palau", "Panama", "Papua New Guinea", "Paraguay", "Peru", "Philippines", "Pitcairn", "Poland", "Portugal", "Puerto Rico", "Qatar", "Reunion", "Romania", "Russian Federation", "Rwanda", "Saint Kitts and Nevis", "Saint Lucia", "Saint Vincent and the Grenadines", "Samoa", "San Marino", "Sao Tome and Principe", "Saudi Arabia", "Senegal", "Seychelles", "Sierra Leone", "Singapore", "Slovakia (Slovak Republic)", "Slovenia", "Solomon Islands", "Somalia", "South Africa", "South Georgia and the South Sandwich Islands", "Spain", "Sri Lanka", "St. Helena", "St. Pierre and Miquelon", "Sudan", "Suriname", "Svalbard and Jan Mayen Islands", "Swaziland", "Sweden", "Switzerland", "Syrian Arab Republic", "Taiwan, Province of China", "Tajikistan", "Tanzania, United Republic of", "Thailand", "Togo", "Tokelau", "Tonga", "Trinidad and Tobago", "Tunisia", "Turkey", "Turkmenistan", "Turks and Caicos Islands", "Tuvalu", "Uganda", "Ukraine", "United Arab Emirates", "United Kingdom", "United States", "United States Minor Outlying Islands", "Uruguay", "Uzbekistan", "Vanuatu", "Venezuela", "Vietnam", "Virgin Islands (British)", "Virgin Islands (U.S.)", "Wallis and Futuna Islands", "Western Sahara", "Yemen", "Yugoslavia", "Zambia", "Zimbabwe");
    shuffle($countries);
    $country = array_shift($countries);

    $OSystems = array('Windows 10', 'Windows 8.1', 'Windows 8', 'Windows 7', 'Windows Vista', 'Windows Server 2003/XP x64', 'Windows XP', 'Windows XP', 'Mac OS X', 'Mac OS 9', 'Linux', 'Ubuntu', 'iPhone', 'iPod', 'iPad', 'Android', 'BlackBerry', 'Windows 10 Home Edition');
    shuffle($OSystems);
    $OS = array_shift($OSystems);

    $ListBrowser = array('Internet Explorer', 'Firefox', 'Safari', 'Chrome', 'Edge', 'Opera', 'Netscape', 'Tor Browser');
    shuffle($ListBrowser);
    $browser = array_shift($ListBrowser);

    $date = date('d M Y');
    $time = date('G:i A');
    $file = file_get_contents($msgfile);
    $arr  = array(
	'++w3ll_email++',
	'++w3ll_subject++',
	'++w3ll_randomip++',
	'++w3ll_frommail++',
	'++w3ll_fromname++',
	'++w3ll_short++',
	'++w3ll_randstring++',
	'++w3ll_country++',
	'++w3ll_date++',
	'++w3ll_number1++',
	'++w3ll_number2++',
	'++w3ll_number3++',
	'++w3ll_number4++',
	'++w3ll_number5++',
	'++w3ll_number6++',
	'++w3ll_number7++',
	'++w3ll_number8++',
	'++w3ll_number9++',
	'++w3ll_number10++',
	'++w3ll_os++',
	'++w3ll_browser++',
	'++w3ll_time++',
	'++w3ll_user++',
	'++w3ll_domain++',
	'++w3ll_secret_email++'
	);
    $new  = array('' . $email . '', '' . $subject . '', '' . $randip . '', '' . $frommail . '', '' . $fromname . '', '' . $randurls . '', '' . $randstr1 . '', '' . $country . '', '' . $date . '', '' . $randnumber1 . '', '' . $randnumber2 . '', '' . $randnumber3 . '', '' . $randnumber4 . '', '' . $randnumber5 . '', '' . $randnumber6 . '', '' . $randnumber7 . '', '' . $randnumber8 . '', '' . $randnumber9 . '', '' . $randnumber10 . '', '' . $OS . '', '' . $browser . '','' . $time . '','' . $user . '','' . $domain . '','' . $secret_mail . '');
    $repl = str_replace($arr, $new, $file);
    return $repl;
};
function Reletter($letter, $mailto)
{
    $file = file_get_contents($letter);
    $arr  = array('++w3ll_email++');
    $new  = array('' . $mailto . '');
    $repl = str_replace($arr, $new, $file);
    return $repl;
};

function berhenti($kata)
{
    $k = strlen($kata);
    if ($k == $k) {
        $p = substr($kata, $k - 1);
        if ($p == 0) {
            echo "Break for 5 seconds...\n";
            sleep(5);
        }}}function Savedata($file, $data)
{
    $file = fopen($file, "w");
    fputs($file, PHP_EOL . $data);
    return fclose($file);
};

function RemoveLine($file, $name)
{
    $getfile  = file_get_contents($file);
    $search   = explode($name, $getfile);
    $save     = $search[1];
    $savedata = Savedata($file, $save);
    return $savedata;
};

system('clear');
require_once("config/phpmailer/PHPMailerAutoload.php");
echo "          \e[1;32mx\e[0m\e[1;94m ██████╗      \e[1;91m███████╗ \e[1;32mx\r\n";
echo "          \e[1;33mx\e[0m\e[1;94m ██╔══██╗     \e[1;91m██╔════╝ \e[1;33mx\r\n";
echo "          \e[1;34mx\e[0m\e[1;94m ██████╔╝     \e[1;91m███████╗ \e[1;34mx\r\n";
echo "          \e[1;35mx\e[0m\e[1;94m ██╔══██╗     \e[1;91m╚════██║ \e[1;35mx\r\n";
echo "          \e[1;36mx\e[0m\e[1;94m ██████╔╝     \e[1;91m███████║ \e[1;36mx\r\n";
echo "          \e[1;37mx\e[0m\e[1;94m ╚═════╝      \e[1;91m╚══════╝ \e[1;37mx\r\n";
echo "                  \e[1;32mx\e[0m  ". versi() ."\e[0m  \e[1;32mx\r\n";
echo "\r\n";
echo "\e[0m  \e[1;94m████████████████████████████████████████████████████\e[0m   \r\n";
echo "\e[0m  \e[1;94m█\e[0m                                        \e[0m         \e[1;94m █\e[0m   \r\n";
echo "\e[0m  \e[1;94m█\e[0m    ╔╦╗╔═╗╦═╗╔╦╗  ╔═╗╔═╗  ╔═╗╔═╗╦═╗╦  ╦╦╔═╗╔═╗\e[0m   \e[1;94m █\e[0m   \r\n";
echo "\e[0m  \e[1;94m█\e[0m     ║ ║╣ ╠╦╝║║║  ║ ║╠╣   ╚═╗║╣ ╠╦╝╚╗╔╝║║  ║╣ \e[0m   \e[1;94m █\e[0m   \r\n";
echo "\e[0m  \e[1;94m█\e[0m     ╩ ╚═╝╩╚═╩ ╩  ╚═╝╚    ╚═╝╚═╝╩╚═ ╚╝ ╩╚═╝╚═╝ \e[0m  \e[1;94m █\e[0m   \r\n";
echo "\e[0m  \e[1;94m█\e[0m                                        \e[0m         \e[1;94m █\e[0m   \r\n";
echo "\e[0m  \e[1;94m█\e[0m  1. Unlimited Sending                  \e[0m         \e[1;94m █\e[0m   \r\n";
echo "\e[0m  \e[1;94m█\e[0m  2. Sender Inbox All 2018              \e[0m         \e[1;94m █\e[0m   \r\n";
echo "\e[0m  \e[1;94m█\e[0m  3. Multi Spam Sender                  \e[0m         \e[1;94m █\e[0m   \r\n";
echo "\e[0m  \e[1;94m█\e[0m  4. Discount 15% For 1 Friend          \e[0m         \e[1;94m █\e[0m   \r\n";
echo "\e[0m  \e[1;94m█\e[0m  5. Premium Sender                     \e[0m         \e[1;94m █\e[0m   \r\n";
echo "\e[0m  \e[1;94m█\e[0m  6. Out From Member If Sell This Stuff Ilegal\e[0m \e[1;94m   █\e[0m   \r\n";
echo "\e[0m  \e[1;91m████████████████████████████████████████████████████\e[0m   \r\n";
echo "\e[0m  \e[1;94m█\e[0m\e[4;37m  Youtube BLACK SECURITY ". versi() ." - SPAM SENDER     \e[1;94m█\e[0m   \r\n";
echo "\r\n";



function Kirim($email, $smtp_acc, $W3LL_setup)
{
    global $ahh, $num;
	$smtp           = new SMTP;
    $smtp->do_debug = 0;

    $smtpserver     = $smtp_acc['host'];
    $smtpport       = $smtp_acc['port'];
    $smtpuser       = $smtp_acc['username'];
    $smtppass       = $smtp_acc['password'];
    $priority       = $W3LL_setup['priority'];
    $userandom      = $W3LL_setup['userandom'];
    $sleeptime      = $W3LL_setup['sleeptime'];
    $replacement    = $W3LL_setup['replacement'];
    $userremoveline = $W3LL_setup['userremoveline'];
    $fromname       = $W3LL_setup['fromname'];
    $frommail       = $W3LL_setup['frommail'];
    $subject        = $W3LL_setup['subject'];
    $msgfile        = $W3LL_setup['msgfile'];
    $filepdf        = $W3LL_setup['filesend'];
    $randurl        = $W3LL_setup['scampage'];

    if (!$smtp->connect($smtpserver, $smtpport)) {
        throw new Exception('Connect failed');
    }


    if (!$smtp->hello(gethostname())) {
        throw new Exception('EHLO failed: ' . $smtp->getError()['error']);
    }

    $e = $smtp->getServerExtList();

    if (array_key_exists('STARTTLS', $e)) {
        $tlsok = $smtp->startTLS();
        if (!$tlsok) {
            throw new Exception('Failed to start encryption: ' . $smtp->getError()['error']);
        }
        if (!$smtp->hello(gethostname())) {
            throw new Exception('EHLO (2) failed: ' . $smtp->getError()['error']);
        }
        $e = $smtp->getServerExtList();
    }

    if (array_key_exists('AUTH', $e)) {

        if ($smtp->authenticate($smtpuser, $smtppass)) {
            $mail           = new PHPMailer;
            $mail->Encoding = 'base64';
            $mail->CharSet  = 'UTF-8';
            $mail->headerLine("format", "flowed");
            $mail->clearAddresses();
            $mail->clearCustomHeaders();
            $mail->clearAllRecipients();
            $mail->addCustomHeader('X-Ebay-Mailtracker', '11400.000.0.0.df812eaca5dd4ebb8aa71380465a8e74');
            $mail->addCustomHeader('x-store-info' , 'sbevkl2QZR7OXo7WID5ZcVBK1Phj2jX');
            $mail->addCustomHeader('X-Brightmail-Tracker' , '94a96329-ea03-4d8a-c064-08d57447496a');
            $mail->addCustomHeader('X-No-Track','11400.000.0.0.47c24ec5-012f-4a87-959a');
            $mail->addCustomHeader('X-IncomingTopHeaderMarker', 'OriginalChecksum:7A4B39E7D056847912D5CA9A44EE97E012CAB89718D96F551AD061D4723C55DB;UpperCasedChecksum:7D1C2902BA6A1D8B04696E190BF0ABC5D6EBBED94E3E13F3C20BC4C79B791BDC;SizeAsReceived:9118;Count:39');
            $mail->addCustomHeader('X-BO1-SAF2-RCPT-Passed' , 'Yes');
            $mail->addCustomHeader('X-Antivirus-Scanner' , 'ClamAV - No Detected Virus, though you should still use a Local Antivirus on your computer.');
            $mail->addCustomHeader('X-Scanned-By' , 'Tzolkin-Spam-Scanner');
            $mail->addCustomHeader('X-Spam-Status: No' , 'score=3.0 required=5.0 tests=BAYES_50,HTML_MESSAGE, UNPARSEABLE_RELAY autolearn=no version=3.3.1');
            $mail->addCustomHeader('X-Spam-Level' , '*');


            $mail->IsSMTP();
            $mail->SMTPAuth = true;
            $mail->Host     = $smtpserver;
            $mail->Port     = $smtpport;
            $mail->Priority = $priority;
            $mail->Username = $smtpuser;
            $mail->Password = $smtppass;

            if ($userandom == 1) {
                $rand     = rand(1, 50);
                $fromname = randName($rand);
                $frommail = randMail($rand);
                $subject  = randSubject($rand);
            }

            if ($W3LL_setup['filesend'] == 1) {
                $filepdf = file_get_contents($AddAttachment);
                $mail->AddAttachment($filepdf);
            }

            $randstr01       = RandString1(8);
            $randstr011      = RandString(5);
            $randstr012      = RandString1(5);
            $nmbr      = RandNumber(5);
            $fromnames = str_replace('++w3ll_randstring++', $randstr011, $fromname);
            $frommails = str_replace('++w3ll_randstring++', $randstr01, $frommail);
            $subjects  = str_replace('++w3ll_randstring++', $randstr012, $subject);
            $randurls   = str_replace('++w3ll_email++', $randstr01 , $randurl);
            $mail->setFrom($frommails, $fromnames);

            $mail->AddAddress($email);

            $mail->Subject = $subjects;
            if ($replacement == 1) {
                $msg = lettering($msgfile, $email, $frommail, $fromname, $randurl, $subject);
            } else {
                $msg = file_get_contents($msgfile);
            }

            $mail->msgHTML($msg);

            if (!$mail->send()) {
                echo "SMTP Error : " . $mail->ErrorInfo;
                exit();
            } else {
				echo "\e[45m[";
                echo $num+1 ."]\e[0m > ";
				echo "\e[0m[\e[44m$email\e[0m] > ";
				echo "\e[0m[\e[42mSENT!\e[0m] \e[0m ==> \e[46m$smtpuser\e[0m \e[43mSTATE\e[0m : \e[42mOK!\e[0m\r\n";
				$file = fopen("Succsess.txt", "a");
                fwrite($file,"Succsess => ". $email." \r\n");
                fclose($file);

            }
            $mail->clearAddresses();

        } else {
				echo "\e[45m[";
                echo $num+1 ."]\e[0m > ";
				echo "\e[0m[\e[44m$email\e[0m] > ";
				echo "\e[0m[\e[41mNOT SENT!\e[0m] \e[0m ==> \e[46m$smtpuser\e[0m \e[43mSTATE\e[0m : \e[41mBAD!\e[0m\r\n";
				$file = fopen("Failed.txt", "a");
                fwrite($file,"Failed => ". $email." \r\n");
                fclose($file);
        }
        }

        $smtp->quit(true);

    }




    $file = file_get_contents($W3LL_setup['mail_list']);
    if ($file) {
        $ext = explode("\n", $file);
        echo "                            \e[1;94m  ████████████████\e[0m                           \r\n";
        echo "\e[0m █████████████████████████████\e[1;32m BLACK SECURITY \e[0m█████████████████████████████\e[0m\n";
		echo "                             \e[1;94m ████████████████\e[0m\r\n";
		echo "\r\n";
        $smtp_key = 0;

		$crot = 0;
        $crotmax = count($fname) - 1;

        foreach ($ext as $num => $email) {

            if ($smtp_key == count($smtp_acc)) {
                $smtp_key = 0;
            }

			            $ahh = $fname[$crot];
            $gx_setup['fromname'] = $ahh;
            $crot++;
            if ($crot >= $crotmax){
                $crot = 0;
            }

            //kirim
            Kirim($email, $smtp_acc[$smtp_key], $W3LL_setup);

            $smtp_key++;

            ///
            sleep($W3LL_setup['sleeptime']);
        }
        if ($W3LL_setup['userremoveline'] == 1) {
            $remove = Removeline($mailist, $email);

        }
		 echo "\n                              \e[1;94m  ███████████\e[0m                           \r\n";
        echo "\e[0m   █████████████████████████████\e[1;32m BLACK SECURITY \e[0m█████████████████████████████\e[0m\n";
		echo "                               \e[1;94m ███████████\e[0m\r\n";
        echo "\r\n";
    }/* ENCRYPTED BY W3LL */
?>
